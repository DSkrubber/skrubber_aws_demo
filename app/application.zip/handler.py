import time


def func(event, context):
    """Calculates fibonacci number for provided user_id via event"""
    time.sleep(1)
    number = event.get("user_id")
    a, b = 1, 1
    for num in range(int(number)):
        b, a = a + b, b
    return str(b)
